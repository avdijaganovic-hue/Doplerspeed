# Doppler Speed (Android)

Experimental Android app that records microphone audio and attempts to estimate vehicle speed from a detected drop in dominant sound frequency. This is a demonstration, not a certified speed measurement device.

## Build
GitHub Actions workflow builds a debug APK at `.github/workflows/build.yml`.

## Limitations
- Sound-source pitch is not guaranteed to remain constant in a real vehicle.
- This first version uses a lightweight dominant-frequency estimator and is not validated against a radar.
- Use from a safe position, never while driving. Do not use for enforcement or safety-critical decisions.
