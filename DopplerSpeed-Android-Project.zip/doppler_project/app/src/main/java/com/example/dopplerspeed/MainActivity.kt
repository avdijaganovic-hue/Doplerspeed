package com.example.dopplerspeed

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

class MainActivity : Activity() {
    private val sampleRate = 16000
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private lateinit var status: TextView
    private lateinit var speed: TextView
    private lateinit var detail: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val history = mutableListOf<String>()
    private var approaching = mutableListOf<Double>()
    private var receding = mutableListOf<Double>()
    private var passed = false
    private var lastFreq = 0.0
    private var lastChangeAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 32)
        window.navigationBarColor = Color.rgb(16, 24, 32)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 12)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(18))
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val title = text("DOPPLER SPEED", 25f, Color.WHITE, true)
        content.addView(title, matchWrap())
        content.addView(text("Procjena brzine preko mikrofona", 14f, Color.LTGRAY), matchWrap())
        content.addView(space(26))
        status = text("Spremno za mjerenje", 16f, Color.rgb(105, 227, 208), true)
        content.addView(status, matchWrap())
        content.addView(space(14))
        speed = text("--", 68f, Color.WHITE, true)
        speed.gravity = Gravity.CENTER
        content.addView(speed, matchWrap())
        val unit = text("km/h", 20f, Color.rgb(105, 227, 208), true)
        content.addView(unit, matchWrap())
        content.addView(space(20))
        detail = text("Pritisni START, pa pusti da automobil priđe i prođe pored telefona. Najbolje radi sa stabilnim tonom motora.", 15f, Color.LTGRAY)
        detail.gravity = Gravity.CENTER
        content.addView(detail, matchWrap())
        content.addView(space(22))
        startButton = Button(this).apply { text = "START MJERENJA"; setOnClickListener { startMeasurement() } }
        content.addView(startButton, fullWrap())
        stopButton = Button(this).apply { text = "ZAUSTAVI / NOVO MJERENJE"; isEnabled = false; setOnClickListener { stopMeasurement(true) } }
        content.addView(stopButton, fullWrap())
        content.addView(space(20))
        content.addView(text("Historija mjerenja", 18f, Color.WHITE, true), matchWrap())
        content.addView(space(6))
        content.addView(text("Napomena: ovo je eksperimentalna procjena, nije certificirani radar. Promjene obrtaja motora, vjetar i drugi zvukovi mogu znatno uticati na rezultat. Koristi samo sa sigurnog mjesta.", 12f, Color.GRAY), matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startMeasurement() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 12); return
        }
        if (running.get()) return
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) { status.text = "Mikrofon nije dostupan"; return }
        val ar = AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, 8192))
        if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); status.text = "Ne mogu pokrenuti mikrofon"; return }
        recorder = ar
        approaching.clear(); receding.clear(); passed = false; lastFreq = 0.0; lastChangeAt = 0L
        running.set(true)
        startButton.isEnabled = false; stopButton.isEnabled = true
        speed.text = "…"; status.text = "Slušam automobil…"
        ar.startRecording()
        thread(name = "AudioAnalyzer") {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val buffer = ShortArray(4096)
            while (running.get()) {
                val n = ar.read(buffer, 0, buffer.size)
                if (n <= 0) continue
                val f = dominantFrequency(buffer, n)
                if (f in 70.0..1800.0) {
                    val now = System.currentTimeMillis()
                    if (lastFreq > 0 && lastChangeAt > 0 && now - lastChangeAt > 180) {
                        val relative = (f - lastFreq) / lastFreq
                        if (!passed && relative < -0.08 && approaching.size >= 3) passed = true
                    }
                    if (!passed) approaching.add(f) else receding.add(f)
                    lastFreq = f; lastChangeAt = now
                    if (approaching.size > 120) approaching.removeAt(0)
                    if (receding.size > 120) receding.removeAt(0)
                    runOnUiThread {
                        detail.text = "Dominantna frekvencija: ${f.toInt()} Hz\nPrije prolaska: ${approaching.size} uzoraka · Poslije: ${receding.size}"
                        if (passed && approaching.size >= 3 && receding.size >= 3) calculateResult()
                    }
                }
            }
            try { ar.stop() } catch (_: Exception) {}
            ar.release()
        }
    }

    private fun calculateResult() {
        val f1 = approaching.takeLast(12).average()
        val f2 = receding.takeLast(12).average()
        if (f1.isFinite() && f2.isFinite() && f1 > f2 && f1 + f2 > 0) {
            val kmh = (343.0 * (f1 - f2) / (f1 + f2) * 3.6).coerceAtMost(350.0)
            speed.text = String.format("%.0f", kmh)
            status.text = "Mogući prolazak detektovan"
        } else {
            status.text = "Analiziram promjenu frekvencije…"
        }
    }

    private fun stopMeasurement(save: Boolean) {
        if (!running.getAndSet(false)) return
        val value = speed.text.toString()
        if (save && value != "--" && value != "…") {
            history.add(0, "${value} km/h  ·  ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
            detail.text = "Rezultat: $value km/h\nMjerenje je završeno. Rezultat je samo procjena i može biti netačan."
        }
        startButton.isEnabled = true; stopButton.isEnabled = false
        status.text = "Mjerenje zaustavljeno"
        recorder = null
    }

    private fun dominantFrequency(samples: ShortArray, n: Int): Double {
        // Hann-windowed FFT-like peak search using selected DFT bins (coarse but light enough for phones).
        val size = minOf(n, 2048)
        val minBin = (70.0 * size / sampleRate).toInt().coerceAtLeast(1)
        val maxBin = (1800.0 * size / sampleRate).toInt().coerceAtMost(size / 2 - 1)
        var bestBin = 0; var bestPower = 0.0
        for (k in minBin..maxBin) {
            var re = 0.0; var im = 0.0
            for (i in 0 until size) {
                val x = samples[i].toDouble() / 32768.0
                val window = 0.5 - 0.5 * cos(2.0 * PI * i / (size - 1))
                val angle = 2.0 * PI * k * i / size
                re += x * window * cos(angle); im -= x * window * kotlin.math.sin(angle)
            }
            val p = re * re + im * im
            if (p > bestPower) { bestPower = p; bestBin = k }
        }
        return bestBin.toDouble() * sampleRate / size
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; setTextColor(color); setTextSize(TypedValue.COMPLEX_UNIT_SP, size); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun space(v: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(v)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun fullWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

    override fun onDestroy() { stopMeasurement(false); super.onDestroy() }
}
